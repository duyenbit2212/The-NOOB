/*###Begin banned keyword - each of the following line if appear in code will raise error. regex supported
define
include
class
[
]
calloc
malloc
new
###End banned keyword*/
#include <iostream>   
using namespace std;
//###INSERT CODE HERE -
                           
